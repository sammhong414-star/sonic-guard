# SONIC GUARD — Website Prototype

A responsive public-safety concept website with an interactive 3D device explorer, component selector, simulated telemetry and a communication-first scenario simulator.

## Run locally
Open `index.html` in a modern browser. For service-worker/PWA testing, serve the folder through a local HTTP server or deploy it to a static host.

## Deploy with Vercel
1. Create a GitHub repository.
2. Upload the contents of this folder (not the ZIP itself) to the repository root.
3. Import that repository in Vercel.
4. Use the default settings for a static site; no build command is required.
5. Deploy.

## Important prototype limitations
- Telemetry values are simulated and are not readings from physical sensors.
- The 3D device is a conceptual visualization, not a validated engineering model.
- Three.js and fonts are loaded from public CDNs, so the 3D preview and typography require internet access.
- No physical output, force, incapacitation, or autonomous enforcement capability is implemented.
- Any real-world use requires qualified engineering, legal, privacy, accessibility and independent safety review.

## Files
- `index.html` — complete responsive website and 3D interface
- `manifest.json` — PWA metadata
- `sw.js` — basic offline caching
- `icon.svg` — application icon
